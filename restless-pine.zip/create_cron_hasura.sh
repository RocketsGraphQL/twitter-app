curl -d '
    {
        "type": "create_cron_trigger",
        "args": {
            "name": "twitter_call",
            "webhook": "https://twkmscssk2yykcuxlfznkadse40jcmco.lambda-url.us-east-2.on.aws/tweet",
            "schedule": "0 22 * * 1-5",
            "payload": {
                {
                    "text": "hello world from scheduled cron job"
                }
            },
            "include_in_metadata": true
        }
    }
' -H "Content-Type: application/json" \
  -H "X-Hasura-Role: admin" \
  -H "X-hasura-admin-secret: a117bb97" \
  -X POST https://hasura-vlklxvo.rocketgraph.app/v1/metadata